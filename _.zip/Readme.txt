This book isn't heavy on code - there are just a few script snippets 
here and there. To figure out how to use them, please consult the 
corresponding chapter.